#!/bin/bash
# Reapply semua fix ke Android.bp/device.mk yang FRESH (abis repo sync /
# abis copy ulang dari _rdbckp_vendor). Jalanin dari /tmp/android_build,
# SETELAH device/samsung/a02 & vendor/samsung/a02 udah jadi folder asli
# (bukan symlink lagi).
set -e
cd /tmp/android_build

VBP="vendor/samsung/a02/Android.bp"
VMK="vendor/samsung/a02/a02-vendor.mk"
DMK="device/samsung/a02/device.mk"

# 1. setprop (bentrok toolbox)
python3 -c "
import re
s=open('$VBP').read()
s=re.sub(r'cc_prebuilt_binary \{\s*name: \"setprop\",.*?\n\}\n', '', s, flags=re.S)
open('$VBP','w').write(s)
"

# 2. start (bentrok toolbox)
python3 -c "
import re
s=open('$VBP').read()
s=re.sub(r'cc_prebuilt_binary \{\s*name: \"start\",.*?\n\}\n', '', s, flags=re.S)
open('$VBP','w').write(s)
"

# 3. semua tool toolbox + toybox sekaligus
sudo grep -oP '"\K[a-z0-9_]+(?=",?$)' system/core/toolbox/Android.bp | sort -u > /tmp/toolbox_names.txt
python3 -c "
import re
s=open('external/toybox/Android.bp').read()
m=re.search(r'name: \"toybox-defaults-symlinks\".*?symlinks: \[(.*?)\]', s, re.S)
names=re.findall(r'\"([a-z0-9_]+)\"', m.group(1))
open('/tmp/toolbox_names.txt','a').write('\n'.join(names)+'\n')
"
sort -u -o /tmp/toolbox_names.txt /tmp/toolbox_names.txt
python3 -c "
import re
names=[l.strip() for l in open('/tmp/toolbox_names.txt') if l.strip()]
s=open('$VBP').read()
for name in names:
    s=re.sub(r'cc_prebuilt_binary \{\s*name: \"'+re.escape(name)+r'\",.*?\n\}\n', '', s, flags=re.S)
open('$VBP','w').write(s)
"

# 4. libwifi-hal.so
python3 -c "
import re
s=open('$VBP').read()
s=re.sub(r'cc_prebuilt_library_shared \{\s*name: \"libwifi-hal_vendor\",.*?\n\}\n', '', s, flags=re.S)
open('$VBP','w').write(s)
"
sed -i '/libwifi-hal_vendor \\/d' "$VMK"

# 5. init.a02.rc
python3 -c "
import re
s=open('$VBP').read()
s=re.sub(r'prebuilt_etc \{\s*name: \"init.a02.rc\",.*?\n\}\n', '', s, flags=re.S)
open('$VBP','w').write(s)
"
sed -i '\#rootdir/etc/init.a02.rc:\$(TARGET_COPY_OUT_VENDOR)/etc/init/init.a02.rc#d' "$DMK"

# 6. fstab.mt6739
python3 -c "
import re
s=open('$VBP').read()
s=re.sub(r'prebuilt_etc \{\s*name: \"fstab.mt6739\",.*?\n\}\n', '', s, flags=re.S)
open('$VBP','w').write(s)
"
sed -i '\#rootdir/etc/fstab.mt6739:\$(TARGET_COPY_OUT_VENDOR)/etc/fstab.mt6739#d' "$DMK"

# 7. Semua prebuilt_etc di "etc/vintf" (manifest, compatibility_matrix, dst):
#    - sub_dir "etc/vintf..." -> "vintf..." (prebuilt_etc udah otomatis di vendor/etc/)
#    - kasih filename eksplisit (basename dari src) biar gak collide sama
#      modul XSD-generated punya nama sama (mis. "manifest", "compatibility_matrix")
python3 -c "
import re
p = '$VBP'
s = open(p).read()
s = re.sub(r'sub_dir: \"etc/vintf', 'sub_dir: \"vintf', s)

def add_filename(m):
    block = m.group(0)
    if 'filename:' in block:
        return block
    src_m = re.search(r'src: \"([^\"]*/)?([^\"/]+)\"', block)
    if not src_m:
        return block
    fname = src_m.group(2)
    return block.rstrip('\n}\n') + '}\n'.join([]) if False else block[:-2] + f'    filename: \"{fname}\",\n}}\n'

s = re.sub(r'prebuilt_etc \{\s*name: \"[^\"]+\",\s*owner: \"samsung\",\s*src: \"proprietary/etc/vintf/[^\"]+\",\s*sub_dir: \"vintf[^\"]*\",\s*vendor: true,\s*\}\n', add_filename, s)
open(p, 'w').write(s)
"

# 8. Bersihin sisa output lama yang kebentuk salah (folder vs file)
rm -rf out/target/product/a02/vendor/etc/vintf/manifest out/target/product/a02/vendor/etc/etc

echo "Fix di-reapply. Lanjut: mka vendorimage (kalau masih ada 'module X already defined' lain, kirim errornya)"

