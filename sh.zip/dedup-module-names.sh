#!/bin/bash
# Rename SEMUA modul di vendor/samsung/a02/Android.bp yang nama-nya bentrok
# sama modul asli di source tree lain (error "module X already defined").
# Jalanin dari /tmp/android_build.
set -e
cd /tmp/android_build

python3 << 'PYEOF'
import re, collections

VBP = 'vendor/samsung/a02/Android.bp'
VMK = 'vendor/samsung/a02/a02-vendor.mk'
DMK = 'device/samsung/a02/device.mk'

# 1. Index semua nama modul di LUAR vendor bp (Android.bp "name:" DAN
#    Android.mk gaya lama "LOCAL_MODULE :=")
print("Scanning seluruh Android.bp + Android.mk di tree (ini agak lama)...")
proc = __import__('subprocess').run(
    ['bash', '-c', 'grep -rl --include=Android.bp --include=Android.mk -E "name:|LOCAL_MODULE" . 2>/dev/null | grep -v ^./out | grep -v "vendor/samsung/a02/Android.bp"'],
    capture_output=True, text=True)
files = proc.stdout.splitlines()

other_names = set()
for f in files:
    try:
        text = open(f, errors='ignore').read()
    except Exception:
        continue
    for n in re.findall(r'name:\s*"([a-zA-Z0-9_.\-@]+)"', text):
        other_names.add(n)
    for n in re.findall(r'LOCAL_MODULE\s*:=\s*([a-zA-Z0-9_.\-@]+)', text):
        other_names.add(n)

print(f"{len(other_names)} nama modul ditemukan di luar vendor bp")

# 2. Ambil semua nama modul di vendor bp, cari yang bentrok
vbp_text = open(VBP).read()
vbp_names = set(re.findall(r'name:\s*"([a-zA-Z0-9_.\-@]+)"', vbp_text))
conflicts = sorted(vbp_names & other_names)
print(f"{len(conflicts)} modul bentrok ditemukan: {conflicts}")

# 3. Rename tiap modul yang bentrok: name: "X" -> name: "X_vendor" + filename: "X"
#    (kalau field filename/stem belum ada)
for name in conflicts:
    pattern = re.compile(
        r'(\w+ \{\s*name: )"' + re.escape(name) + r'"(,\s*)',
    )
    def repl(m, name=name):
        return m.group(1) + f'"{name}_vendor"' + m.group(2)
    new_text, count = pattern.subn(repl, vbp_text, count=1)
    if count == 0:
        continue
    vbp_text = new_text
    # sisipin filename/stem kalau block itu belum punya field itu.
    # cc_prebuilt_* pake "stem:", prebuilt_etc pake "filename:".
    block_pat = re.compile(r'(name: "' + re.escape(name) + r'_vendor",.*?)(\n\})', re.S)
    bm = block_pat.search(vbp_text)
    if bm and 'filename:' not in bm.group(1) and 'stem:' not in bm.group(1):
        # cek tipe modul dari baris sebelum "name:" pada block ini
        before = vbp_text[:bm.start()]
        type_m = re.search(r'(\w+) \{\s*$', before[-200:])
        field = 'stem' if (type_m and type_m.group(1).startswith('cc_prebuilt')) else 'filename'
        vbp_text = vbp_text[:bm.end(1)] + f'\n    {field}: "{name}",' + vbp_text[bm.end(1):]

open(VBP, 'w').write(vbp_text)

# 4. Update referensi nama lama -> nama baru di PRODUCT_PACKAGES (a02-vendor.mk & device.mk)
for mkfile in [VMK, DMK]:
    try:
        text = open(mkfile).read()
    except FileNotFoundError:
        continue
    changed = False
    for name in conflicts:
        # ganti baris "    name \" jadi "    name_vendor \" (word boundary, hindari
        # kena substring nama modul lain)
        newtext, n = re.subn(r'(?<![\w.-])' + re.escape(name) + r'(?![\w.-])', name + '_vendor', text)
        if n:
            text = newtext
            changed = True
    if changed:
        open(mkfile, 'w').write(text)

print("Selesai rename. Modul yang di-rename:", conflicts)
PYEOF

rm -rf out/target/product/a02/vendor/etc/vintf/manifest out/target/product/a02/vendor/etc/etc
echo "Lanjut: mka vendorimage"
